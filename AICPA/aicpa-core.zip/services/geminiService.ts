import { GoogleGenAI, GenerateContentResponse, Chat, Type, Schema } from "@google/genai";
import { BriefingItem, RcateData, KnowledgeDoc, WorkflowStep, AgentRole } from '../types';

// --- API CLIENT FACTORY ---
const getAiClient = () => {
  let apiKey = '';
  
  // PRIORITY 1: Environment Variable
  try {
    if (typeof process !== 'undefined' && process.env && process.env.API_KEY) {
      apiKey = process.env.API_KEY;
    }
  } catch (e) {}

  if (apiKey) {
      return new GoogleGenAI({ apiKey });
  }

  // PRIORITY 2: LocalStorage
  const devKey = typeof window !== 'undefined' ? localStorage.getItem('gemini_api_key') : null;
  if (devKey) {
      return new GoogleGenAI({ apiKey: devKey });
  }

  console.warn("No API Key found. Using Mock Data/Fallback Mode.");
  return new GoogleGenAI({ apiKey: 'no-key-provided' });
};

// --- MOCK DATA ---
const getMockBriefing = (location: string): BriefingItem[] => [
    { category: 'Local', headline: `${location} 지역 경제, 전년 대비 3.2% 성장세 기록`, url: '#' },
    { category: 'CPA', headline: '2025년 세법 개정안 주요 포인트: 상속세 완화 논의', url: '#' },
    { category: 'Tech', headline: 'AI 감사(Audit) 툴 도입 기업, 생산성 40% 향상', url: '#' },
    { category: 'Tip', headline: '바쁜 시즌(Busy Season) 번아웃 관리 가이드', url: '#' }
];

const getMockReview = () => ({
    score: 85,
    summary: "전반적으로 훌륭한 전략입니다. 특히 리스크 관리 부분이 구체적입니다.",
    strengths: ["명확한 역할 정의", "보수적인 시나리오 분석"],
    weaknesses: ["구체적인 타임라인 부재", "실행 예산 미언급"],
    refined_suggestion: "실행 계획 단계에서 주 단위 마일스톤을 추가하면 완벽할 것입니다."
});

// --- UTILITY ---
const extractJson = <T>(text: string, fallback: T): T => {
  try {
    return JSON.parse(text);
  } catch (e) {
    const match = text.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
    if (match) {
      try { return JSON.parse(match[0]); } catch (e2) {}
    }
    const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
    try { return JSON.parse(cleaned); } catch (e3) { return fallback; }
  }
};

async function safeCall<T>(operation: () => Promise<T>, fallbackValue: T, contextName: string): Promise<T> {
    try {
        return await operation();
    } catch (error: any) {
        console.warn(`[Gemini] ${contextName} Error:`, error.message);
        return fallbackValue;
    }
}

// --- SCHEMAS ---
const StringArraySchema: Schema = {
  type: Type.ARRAY,
  items: { type: Type.STRING }
};

const RcateSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    role: { type: Type.STRING },
    context: { type: Type.STRING },
    audience: { type: Type.STRING },
    task: { type: Type.STRING },
    execution: { type: Type.STRING }
  },
  required: ['role', 'context', 'audience', 'task', 'execution']
};

const ReviewSchema: Schema = {
    type: Type.OBJECT,
    properties: {
        score: { type: Type.INTEGER, description: "Score from 0 to 100 based on logical soundness." },
        summary: { type: Type.STRING, description: "Brief executive summary of the review." },
        strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
        weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
        refined_suggestion: { type: Type.STRING, description: "One specific suggestion to improve the strategy." }
    },
    required: ["score", "summary", "strengths", "weaknesses", "refined_suggestion"]
};

// --- EXPORTED FUNCTIONS ---

export const runAgentDrafting = async function* (rcateData: RcateData) {
    try {
        const fullPrompt = `ROLE: ${rcateData.role}\nCONTEXT: ${rcateData.context}\nAUDIENCE: ${rcateData.audience}\nTASK: ${rcateData.task}\nEXECUTION: ${rcateData.execution}`;
        const prompt = `
        Draft a comprehensive strategy document based on this R.C.A.T.E framework.
        Input:
        ${fullPrompt}
        
        Output Format: Markdown.
        Language: Korean.
        Structure:
        # Strategy Plan
        ## 1. Executive Summary
        ## 2. Risk Analysis
        ## 3. Action Plan (Step-by-step)
        `;
        
        const ai = getAiClient();
        const result = await ai.models.generateContentStream({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: { temperature: 0.7 }
        });
        
        for await (const chunk of result) {
            if (chunk.text) yield chunk.text;
        }
    } catch (error) {
        yield "AI Connection Error. Please check your API Key.";
    }
};

export const runAgentManagerReview = async (draft: string) => {
    return safeCall(async () => {
        const ai = getAiClient();
        const prompt = `
            Act as a Senior Audit Partner. Review the following strategy draft.
            Draft: ${draft.substring(0, 3000)}...
            
            Evaluate based on:
            1. Logic & Feasibility
            2. Compliance (Risk)
            3. Clarity
            
            Return JSON.
        `;
        
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: prompt,
            config: { 
                responseMimeType: 'application/json',
                responseSchema: ReviewSchema,
                temperature: 0.2
            }
        });
        
        return JSON.parse(response.text || "{}");
    }, getMockReview(), 'ManagerReview');
};

export const createChatSession = (): Chat => {
  const ai = getAiClient();
  return ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction: "You are 'AICPA Core', an advanced AI assistant for CPAs.",
    }
  });
};

export const generateDailyBriefing = async (location: string, language: 'ko' | 'en' = 'en'): Promise<BriefingItem[]> => {
    return safeCall(async () => {
        const ai = getAiClient();
        const langInstruction = language === 'ko' ? "Translate headlines to Korean." : "Keep headlines in English.";
        const prompt = `
          Search for latest news in ${location} related to: Local Economy, US CPA News, Tech Tips.
          Return JSON Array of 6 items.
          Keys: "category", "headline", "url".
          ${langInstruction}
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: { tools: [{ googleSearch: {} }] },
        });
        const rawData = extractJson<any[]>(response.text || "[]", []);
        return rawData.map(item => ({
            category: (['Local', 'Economy', 'CPA', 'Tech', 'Tip'].includes(item.category) ? item.category : 'Tip') as any,
            headline: item.headline || item.title || 'Latest News',
            url: item.url || '#'
        })).slice(0, 4);
    }, getMockBriefing(location), 'DailyBriefing');
};

export const generateFieldOptions = async (field: keyof RcateData, currentData: RcateData): Promise<string[]> => {
    return safeCall(async () => {
        const ai = getAiClient();
        const prompt = `Context: ${JSON.stringify(currentData)}. Suggest 3 alternative professional options for the field '${field}' in Korean.`;
        const response = await ai.models.generateContent({ 
            model: 'gemini-2.5-flash', 
            contents: prompt,
            config: { responseMimeType: 'application/json', responseSchema: StringArraySchema }
        });
        return JSON.parse(response.text || "[]");
    }, ["Option A", "Option B", "Option C"], 'FieldOptions');
};

export const optimizeRcatePrompt = async (currentData: RcateData): Promise<RcateData | null> => {
    return safeCall(async () => {
        const ai = getAiClient();
        const prompt = `
            Act as a Prompt Engineer for CPAs. Optimize input R.C.A.T.E data.
            Input: ${JSON.stringify(currentData)}
            Make it professional, precise. Korean.
        `;
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: prompt,
            config: { responseMimeType: 'application/json', responseSchema: RcateSchema }
        });
        return JSON.parse(response.text);
    }, currentData, 'OptimizePrompt');
};

export const refineRcateWithWebGrounding = async (currentData: RcateData) => currentData;
export const benchmarkStrategy = async (currentData: RcateData) => currentData;

export const analyzeClientDocumentsForRcate = async (docs: KnowledgeDoc[]) => {
    return {
        role: "Financial Analyst",
        context: `Analyzed ${docs.length} document(s). Detected revenue figures and potential compliance risks in Q3.`,
        audience: "CFO & Audit Team",
        task: "Investigate revenue recognition anomalies and prepare variance analysis.",
        execution: "Draft a detailed memo with findings and recommendations."
    } as RcateData;
};

export const generateAgentReply = async (role: AgentRole, history: string) => {
    return `[${role}] acknowledged. I have reviewed the context and suggest focusing on the regulatory compliance aspects mentioned in the latest data.`;
};

export const generateInterviewQuestion = async (step: string, inputs: any[]) => {
    const steps = ['역할 (Role)', '상황 (Context)', '청중 (Audience)', '임무 (Task)', '실행 (Execution)'];
    const idx = inputs.length;
    if (idx >= steps.length) return "모든 단계가 완료되었습니다. 전략 생성을 시작할까요?";
    
    if (step.includes('Role')) return "어떤 전문가 페르소나로 프로젝트를 수행하시겠습니까? (예: 내부 감사인, 세무 전문가)";
    if (step.includes('Context')) return "현재 클라이언트가 직면한 상황이나 분석해야 할 데이터에 대해 설명해주세요.";
    if (step.includes('Audience')) return "이 보고서의 주요 독자는 누구입니까?";
    if (step.includes('Task')) return "구체적으로 어떤 작업을 수행해야 합니까? (예: 리스크 평가, 절세 방안 도출)";
    if (step.includes('Execution')) return "결과물은 어떤 형식이어야 하며, 어떤 검증 과정을 거쳐야 합니까?";
    
    return "다음 단계에 대한 정보를 입력해주세요.";
};

export const generateRcateFromInterview = async (inputs: any[]) => {
     return {
        role: inputs.find(i => i.step === 'ROLE')?.answer || "Role",
        context: inputs.find(i => i.step === 'CONTEXT')?.answer || "Context",
        audience: inputs.find(i => i.step === 'AUDIENCE')?.answer || "Audience",
        task: inputs.find(i => i.step === 'TASK')?.answer || "Task",
        execution: inputs.find(i => i.step === 'EXECUTION')?.answer || "Execution",
     } as RcateData;
};

export const generateSyntheticFinancialData = async () => {
    return [
        {
            id: `syn-${Date.now()}-1`,
            name: 'FY23_Financial_Statements.xlsx',
            type: 'EXCEL',
            size: '2.4 MB',
            uploadDate: new Date(),
            content: "base64...",
            mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            summary: 'Synthetic Balance Sheet & Income Statement'
        },
        {
            id: `syn-${Date.now()}-2`,
            name: 'Board_Meeting_Minutes_Q3.pdf',
            type: 'PDF',
            size: '1.1 MB',
            uploadDate: new Date(),
            content: "base64...",
            mimeType: 'application/pdf',
            summary: 'Discussion on merger acquisition targets'
        }
    ] as KnowledgeDoc[];
};

export const runBrowserAgent = async function* (step: string, docId: string, context: string = '') {
    const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
    
    if (step === 'READ_EXCEL') {
        const mockData = `
        <div style="font-family: 'Segoe UI', sans-serif;">
            <table style="width:100%; border-collapse: collapse; font-size: 13px; border: 1px solid #dcdcdc;">
                <tr style="background-color: #f8f9fa; color: #444; font-weight: bold;">
                    <th style="padding: 10px; border: 1px solid #e2e2e2;">Date</th>
                    <th style="padding: 10px; border: 1px solid #e2e2e2;">Transaction ID</th>
                    <th style="padding: 10px; border: 1px solid #e2e2e2;">Description</th>
                    <th style="padding: 10px; border: 1px solid #e2e2e2; text-align: right;">Amount ($)</th>
                    <th style="padding: 10px; border: 1px solid #e2e2e2;">Status</th>
                </tr>
                <tr>
                    <td style="padding: 8px; border: 1px solid #e2e2e2;">2024-01-15</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; color: #666;">TXN-1002</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2;">Vendor Payment - TechCorp</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; text-align: right; color: #dc2626;">(15,000.00)</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; color: #059669;">Cleared</td>
                </tr>
                <tr style="background-color: #fcfcfc;">
                    <td style="padding: 8px; border: 1px solid #e2e2e2;">2024-01-20</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; color: #666;">TXN-1005</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2;">Client Retainer - Alpha</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; text-align: right; font-weight: bold;">50,000.00</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; color: #059669;">Cleared</td>
                </tr>
                <tr>
                    <td style="padding: 8px; border: 1px solid #e2e2e2;">2024-02-05</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; color: #666;">TXN-1011</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2;">Office Lease - Q1</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; text-align: right; color: #dc2626;">(4,500.00)</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; color: #d97706;">Pending</td>
                </tr>
                <tr style="background-color: #fcfcfc;">
                    <td style="padding: 8px; border: 1px solid #e2e2e2;">2024-02-12</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; color: #666;">TXN-1015</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2;">SaaS Subscription</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; text-align: right; color: #dc2626;">(2,000.00)</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; color: #059669;">Cleared</td>
                </tr>
                <tr>
                    <td style="padding: 8px; border: 1px solid #e2e2e2;">2024-02-28</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; color: #666;">TXN-1022</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2;">Consulting Fee - Beta</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; text-align: right; font-weight: bold;">35,000.00</td>
                    <td style="padding: 8px; border: 1px solid #e2e2e2; color: #059669;">Cleared</td>
                </tr>
            </table>
        </div>
        `;
        const chunk1 = mockData.substring(0, mockData.length / 3);
        const chunk2 = mockData.substring(mockData.length / 3, 2 * mockData.length / 3);
        const chunk3 = mockData.substring(2 * mockData.length / 3);
        yield chunk1; await delay(200); yield chunk2; await delay(200); yield chunk3; await delay(200);

    } else if (step === 'ANALYZE') {
        const analysis = `
        <h3 style="color: #4ade80; margin-bottom: 12px; font-family: monospace;">> EXECUTING FINANCIAL ANALYSIS PROTOCOL...</h3>
        <div style="border-left: 2px solid #3b82f6; padding-left: 10px; margin-bottom: 10px;">
            <strong style="color: #60a5fa;">[REVENUE STREAM]</strong><br/>
            Identified total inflow of <strong>$85,000</strong>. Growth trajectory matches Q1 projections.<br/>
            <span style="color: #94a3b8; font-size: 11px;">Source: TXN-1005, TXN-1022</span>
        </div>
        <div style="border-left: 2px solid #f59e0b; padding-left: 10px; margin-bottom: 10px;">
            <strong style="color: #fbbf24;">[EXPENSE AUDIT]</strong><br/>
            Total outflow: <strong>$21,500</strong>. Lease payment (TXN-1011) flagged as 'Pending'.<br/>
            <span style="color: #94a3b8; font-size: 11px;">Action: Verify bank clearance.</span>
        </div>
        <div style="border-left: 2px solid #10b981; padding-left: 10px;">
            <strong style="color: #34d399;">[COMPLIANCE]</strong><br/>
            GAAP Revenue Recognition standards met. No commingling detected.<br/>
        </div>
        <br/>
        <span style="color: #94a3b8;">> Data integrity verified (SHA-256). Proceeding to documentation...</span>
        `;
        const words = analysis.split(/(?=[<>])/);
        for (const word of words) { yield word; await delay(10); }

    } else if (step === 'WRITE_WORD') {
         const memo = `
         <div style="font-family: 'Times New Roman', serif; color: #000; padding: 20px;">
             <h1 style="font-size: 20px; text-align: center; text-transform: uppercase; margin-bottom: 30px; letter-spacing: 1px;">Internal Audit Memorandum</h1>
             
             <table style="width: 100%; margin-bottom: 25px; border-bottom: 2px solid #000; padding-bottom: 10px;">
                <tr><td style="font-weight: bold; width: 80px;">TO:</td><td>Audit Committee</td></tr>
                <tr><td style="font-weight: bold;">FROM:</td><td>AICPA Core Agent (ID: ${docId.substring(0,6)})</td></tr>
                <tr><td style="font-weight: bold;">DATE:</td><td>${new Date().toLocaleDateString()}</td></tr>
                <tr><td style="font-weight: bold;">RE:</td><td>Q1 Financial Review & Risk Assessment</td></tr>
             </table>
             
             <h3 style="font-size: 14px; font-weight: bold; margin-top: 20px; text-decoration: underline;">1. EXECUTIVE SUMMARY</h3>
             <p style="margin-bottom: 15px; line-height: 1.5; text-align: justify;">
                We have conducted a limited review of the financial records provided. The objective was to assess the accuracy of revenue recognition and the validity of operating expenses. Based on our procedures, the financial health appears robust with a <strong>Net Profit Margin of 74.7%</strong>.
             </p>
             
             <h3 style="font-size: 14px; font-weight: bold; margin-top: 20px; text-decoration: underline;">2. KEY FINDINGS</h3>
             <ul style="margin-bottom: 15px; line-height: 1.5;">
                <li><strong>Revenue:</strong> Confirmed $85,000 from Client Retainers and Consulting Fees.</li>
                <li><strong>Expenses:</strong> $21,500 total. One lease payment ($4,500) remains pending clearance.</li>
                <li><strong>Compliance:</strong> No material misstatements or GAAP deviations were identified.</li>
             </ul>
             
             <h3 style="font-size: 14px; font-weight: bold; margin-top: 20px; text-decoration: underline;">3. RECOMMENDATIONS</h3>
             <p style="margin-bottom: 15px; line-height: 1.5;">
                We recommend immediate reconciliation of the pending lease payment to avoid late fees. Proceed with quarterly filing.
             </p>
         </div>
         `;
         const chunks = memo.match(/.{1,20}/g) || [];
         for (const chunk of chunks) { yield chunk; await delay(30); }
    } else {
        yield "Processing...";
    }
};