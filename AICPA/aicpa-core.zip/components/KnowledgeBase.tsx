import React, { useState, useRef } from 'react';
import { Folder, FileText, Upload, Plus, Trash2, Bot, Cloud, Zap, Loader2, RefreshCw, Video, FileSpreadsheet, File as FileIcon, ExternalLink, Play } from 'lucide-react';
import { KnowledgeDoc, KnowledgeFolder, AuthUser, RcateData } from '../types';
import { analyzeClientDocumentsForRcate, generateSyntheticFinancialData } from '../services/geminiService';
import { useApp } from '../context/AppContext';

interface KnowledgeBaseProps {
  folders: KnowledgeFolder[];
  setFolders: React.Dispatch<React.SetStateAction<KnowledgeFolder[]>>;
  activeFolderId: string | null;
  setActiveFolderId: (id: string) => void;
  user: AuthUser | null;
  onGenerateStrategy?: (data: RcateData) => void;
}

const MAX_FILE_SIZE_MB = 10;

export const KnowledgeBase: React.FC<KnowledgeBaseProps> = ({ folders, setFolders, activeFolderId, setActiveFolderId, user, onGenerateStrategy }) => {
  const { showNotification, startBrowserAgent } = useApp();
  const [isUploading, setIsUploading] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const activeFolder = folders.find(f => f.id === activeFolderId);

  const handleCreateFolder = () => {
    const name = prompt("Notebook Title (e.g., Tech Corp Audit 2024):");
    if (name) {
      const newFolder: KnowledgeFolder = {
        id: Date.now().toString(),
        name,
        docs: []
      };
      setFolders([...folders, newFolder]);
      setActiveFolderId(newFolder.id);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || !activeFolderId) return;

    setIsUploading(true);
    setUploadStatus('Processing files...');
    const newDocs: KnowledgeDoc[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
          alert(`File "${file.name}" is too large. Max ${MAX_FILE_SIZE_MB}MB.`);
          continue;
      }
      const reader = new FileReader();
      await new Promise<void>((resolve) => {
        reader.onloadend = async () => {
          const base64Content = (reader.result as string).split(',')[1];
          let docType: KnowledgeDoc['type'] = 'TEXT';
          if (file.type.includes('pdf')) docType = 'PDF';
          else if (file.type.includes('sheet') || file.type.includes('csv')) docType = 'EXCEL';
          else if (file.type.includes('word')) docType = 'WORD';
          else if (file.type.includes('video')) docType = 'VIDEO';

          newDocs.push({
            id: Date.now().toString() + i,
            name: file.name,
            type: docType,
            size: (file.size / 1024).toFixed(1) + ' KB',
            uploadDate: new Date(),
            content: base64Content,
            mimeType: file.type,
            summary: `Uploaded file`
          });
          resolve();
        };
        reader.readAsDataURL(file);
      });
    }

    if (newDocs.length > 0) {
        setFolders(prev => prev.map(f => {
          if (f.id === activeFolderId) return { ...f, docs: [...f.docs, ...newDocs] };
          return f;
        }));
    }
    setIsUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSyntheticDataImport = async () => {
    if(!activeFolderId) return;
    setIsUploading(true);
    setUploadStatus(`Connecting to AI Generator...`);
    try {
        const syntheticDocs = await generateSyntheticFinancialData();
        setFolders(prev => prev.map(f => {
            if (f.id === activeFolderId) {
                return { ...f, docs: [...f.docs, ...syntheticDocs] };
            }
            return f;
        }));
    } catch (e) {
        alert("Failed to generate synthetic data.");
    } finally {
        setIsUploading(false);
        setUploadStatus('');
    }
  };

  const handleGenerateStrategy = async () => {
    if (!activeFolder || activeFolder.docs.length === 0) {
        alert("Please upload documents first.");
        return;
    }
    setIsAnalyzing(true);
    try {
        const rcateData = await analyzeClientDocumentsForRcate(activeFolder.docs);
        if (rcateData && onGenerateStrategy) {
            onGenerateStrategy(rcateData);
            showNotification("R.C.A.T.E. Strategy generated from documents.", "success");
        } else {
            alert("Failed to generate strategy.");
        }
    } catch (e) {
        alert("Error during analysis.");
    } finally {
        setIsAnalyzing(false);
    }
  };

  const handleMockOpenInBrowser = (doc: KnowledgeDoc) => {
      showNotification(`Opening "${doc.name}" in Viewer...`, 'info');
  };

  const handleRunAutomation = (doc: KnowledgeDoc) => {
      startBrowserAgent(doc);
  };

  const getIconForType = (type: string) => {
    switch (type) {
      case 'PDF': return <FileText className="text-red-500" size={24} />;
      case 'EXCEL': return <FileSpreadsheet className="text-emerald-600" size={24} />;
      case 'WORD': return <FileIcon className="text-blue-600" size={24} />;
      case 'VIDEO': return <Video className="text-purple-600" size={24} />;
      default: return <FileText className="text-slate-400" size={24} />;
    }
  };

  return (
    <div className="flex h-[calc(100vh-4rem)] bg-white">
      <div className="w-72 bg-slate-50 border-r border-slate-200 flex flex-col">
        <div className="p-4 border-b border-slate-200 bg-white">
           <h2 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4 flex items-center gap-2">
             <Folder size={12} /> Your Notebooks
           </h2>
           <button 
            onClick={handleCreateFolder}
            className="w-full flex items-center justify-center gap-2 bg-slate-900 text-white py-3 rounded-xl hover:bg-slate-800 transition-colors shadow-sm text-sm font-medium"
          >
            <Plus size={16} /> New Notebook
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-3 space-y-1">
          {folders.length === 0 && (
              <div className="text-center py-8 px-4 text-slate-400 text-xs">
                  <p>No notebooks created.</p>
              </div>
          )}
          {folders.map(folder => (
            <button
              key={folder.id}
              onClick={() => setActiveFolderId(folder.id)}
              className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm transition-all group ${
                activeFolderId === folder.id 
                  ? 'bg-white text-emerald-800 font-bold shadow-md ring-1 ring-emerald-100' 
                  : 'text-slate-600 hover:bg-white hover:text-slate-900 hover:shadow-sm'
              }`}
            >
              <div className={`p-1.5 rounded-lg transition-colors ${activeFolderId === folder.id ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-200 text-slate-500 group-hover:bg-emerald-50 group-hover:text-emerald-500'}`}>
                <Folder size={16} />
              </div>
              <div className="flex-1 text-left truncate">
                  <span className="block truncate">{folder.name}</span>
                  <span className="text-[10px] text-slate-400 font-normal">{folder.docs.length} sources</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 flex flex-col bg-white">
        {activeFolder ? (
          <>
            <div className="h-20 border-b border-slate-100 flex items-center justify-between px-8 bg-white/80 backdrop-blur-sm sticky top-0 z-10">
              <div>
                <h2 className="text-2xl font-bold text-slate-900 tracking-tight">{activeFolder.name}</h2>
                <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                    <span className="bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full font-bold border border-emerald-100">{activeFolder.docs.length} sources</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                 {activeFolder.docs.length > 0 && (
                     <button
                        onClick={handleGenerateStrategy}
                        disabled={isAnalyzing}
                        className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-lg hover:shadow-emerald-500/30 hover:-translate-y-0.5 transition-all mr-2"
                     >
                        {isAnalyzing ? <Loader2 size={16} className="animate-spin" /> : <Zap size={16} />}
                        {isAnalyzing ? "Processing..." : "Generate R.C.A.T.E."}
                     </button>
                 )}
                
                <button 
                  onClick={handleSyntheticDataImport}
                  className="flex items-center gap-2 text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 hover:border-slate-300 px-4 py-2.5 rounded-xl text-sm font-medium transition-all"
                >
                  <Bot size={18} className="text-purple-500" /> <span className="hidden sm:inline">AI Gen Data</span>
                </button>

                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-2 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-4 py-2.5 rounded-xl text-sm font-medium transition-all border border-emerald-200"
                >
                  <Upload size={18} /> Upload
                </button>
                <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" multiple accept=".pdf,.csv,.xlsx,.xls,.doc,.docx,.txt,image/*,video/*" />
              </div>
            </div>

            <div className="flex-1 p-8 overflow-y-auto bg-[#f8fafc]">
              {activeFolder.docs.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-400">
                  <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mb-6 text-emerald-200 shadow-sm border border-slate-100">
                    <Cloud size={48} />
                  </div>
                  <h3 className="font-bold text-xl text-slate-700 mb-2">No Sources Yet</h3>
                  <p className="text-sm text-center max-w-sm mb-8 text-slate-500 leading-relaxed">
                     Upload client documents or use the AI generator to create synthetic data for testing.
                  </p>
                  <button 
                        onClick={handleSyntheticDataImport}
                        className="px-6 py-3 bg-white border border-slate-200 text-slate-700 rounded-xl hover:bg-slate-50 hover:shadow-sm transition-all font-medium text-sm flex items-center gap-2"
                    >
                        <Bot size={18} className="text-purple-500" /> Generate Sample Data
                    </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {activeFolder.docs.map(doc => (
                        <div key={doc.id} className="bg-white p-6 rounded-[1.5rem] border border-slate-200 shadow-sm hover:shadow-xl hover:-translate-y-1 hover:border-emerald-200 transition-all group relative animate-slide-down flex flex-col duration-300">
                            <div className="flex justify-between items-start mb-4">
                                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 group-hover:bg-emerald-50 group-hover:border-emerald-100 transition-colors">
                                    {getIconForType(doc.type)}
                                </div>
                                <div className="flex gap-1">
                                    <button 
                                        onClick={() => handleMockOpenInBrowser(doc)}
                                        className="p-2 hover:bg-slate-100 rounded-full text-slate-400 hover:text-emerald-600 transition-colors"
                                        title="Open in Viewer"
                                    >
                                        <ExternalLink size={16} />
                                    </button>
                                    {(doc.type === 'EXCEL' || doc.type === 'WORD' || doc.type === 'PDF') && (
                                        <button 
                                            onClick={() => handleRunAutomation(doc)}
                                            className="p-2 bg-emerald-50 hover:bg-emerald-100 rounded-full text-emerald-600 transition-colors animate-pulse"
                                            title="Run Agent Workflow"
                                        >
                                            <Play size={16} fill="currentColor" />
                                        </button>
                                    )}
                                </div>
                            </div>
                            <h3 className="font-bold text-slate-900 mb-2 truncate leading-snug" title={doc.name}>{doc.name}</h3>
                            <div className="flex items-center gap-3 text-xs text-slate-400 mb-5">
                                <span className="font-medium bg-slate-100 px-2 py-0.5 rounded">{doc.type}</span>
                                <span>{doc.size}</span>
                            </div>
                            <div className="bg-slate-50/80 p-3 rounded-xl border border-slate-100 mt-auto group-hover:bg-white group-hover:border-emerald-100 transition-colors">
                                <p className="text-xs text-slate-500 leading-relaxed line-clamp-2">
                                    {doc.summary || "Ready for analysis."}
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
              )}
            </div>
            
            {(isUploading || isAnalyzing) && (
                <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center z-50 animate-fade-in">
                    <div className="bg-white p-8 rounded-[2rem] shadow-2xl border border-slate-100 flex flex-col items-center ring-1 ring-slate-200">
                        <RefreshCw size={40} className="text-emerald-600 animate-spin mb-4" />
                        <h3 className="text-xl font-bold text-slate-900 mb-1">AI Working</h3>
                        <p className="text-slate-500 text-sm font-medium">{uploadStatus || 'Analyzing content...'}</p>
                    </div>
                </div>
            )}
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-400 bg-slate-50/50">
             <h2 className="text-2xl font-bold text-slate-800 mb-2">Select a Notebook</h2>
             <p className="text-sm text-slate-500">Choose a notebook from the sidebar to view documents.</p>
          </div>
        )}
      </div>
    </div>
  );
};